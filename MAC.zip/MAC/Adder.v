`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: Qiuhao Zeng
// 
// Create Date: 2025/04/14
// Design Name: 
// Module Name: Adder
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module Adder #(
    parameter A_width = 16       ,
    parameter Scale   = 3 
)(
    input  [Scale*A_width-1:0] A ,
    output signed [A_width+Scale-2:0] S        
);
wire signed [A_width-1:0] A_array [0:Scale-1] ;

// A_array
genvar i;
generate
    for(i=0; i<Scale; i=i+1)begin
        assign A_array[i] = A[Scale*A_width-i*A_width-1-:A_width] ;
    end
endgenerate

// S
assign S = A_array[0] + A_array[1] + A_array[2];
    
endmodule