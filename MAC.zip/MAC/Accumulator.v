`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: Qiuhao Zeng
// 
// Create Date: 2025/04/14
// Design Name: 
// Module Name: Accumulator
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module Accumulator #(
    parameter A_width = 18 ,
    parameter S_width = 8 
)(
    input                I_clk        ,
    input                I_rst_n      ,
    input                I_acc_reset  ,
    input                I_acc_clean  ,
    input [A_width-1:0]  A            ,
    output [S_width-1:0] S        
);
localparam Ext_width = 3 ;
wire [A_width+Ext_width-1:0] A_Ext   ;
reg  [A_width+Ext_width-1:0] S_temp  ;

// A_Ext
assign A_Ext = {{Ext_width{A[A_width-1]}}, A};

// S_temp
always@(posedge I_clk)begin
    if(!I_rst_n)begin
        S_temp <= 'd0;
    end else if(I_acc_reset)begin
        S_temp <= 'd0;
    end else if(I_acc_clean)begin
        S_temp <= A_Ext;
    end else begin
        S_temp <= S_temp + A_Ext;
    end
end

assign S = ($signed(S_temp) < -21'sd128)?8'b1000_0000:(($signed(S_temp) > 21'sd127)?8'b0111_1111:S_temp[S_width-1:0]);
    
endmodule