`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: Qiuhao Zeng
// 
// Create Date: 2025/04/14
// Design Name: 
// Module Name: Multiplier
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module Multiplier #(
    parameter A_width = 8 ,
    parameter B_width = 8 ,
    parameter Scale   = 3 
)(
    input                                 I_clk   ,
    input                                 I_rst_n ,
    input [Scale*A_width-1:0]             A       ,
    input [Scale*B_width-1:0]             B       ,
    output [Scale*(A_width+B_width)-1:0]  S        
);
wire signed [A_width-1:0]         A_array [0:Scale-1];
wire signed [B_width-1:0]         B_array [0:Scale-1];
reg  signed [A_width+B_width-1:0] S_array [0:Scale-1];

// A_array and B_array
genvar i;
generate
    for(i=0; i<Scale; i=i+1)begin
        assign A_array[i] = A[Scale*A_width-i*A_width-1-:A_width] ;
        assign B_array[i] = B[Scale*B_width-i*B_width-1-:B_width] ;
    end
endgenerate

// S_array
genvar j;
generate
    for(j=0; j<Scale; j=j+1)begin
        always@(posedge I_clk)begin
            if(!I_rst_n)begin
                S_array[j] <= 'd0   ;
            end else begin
                S_array[j] <= A_array[j] * B_array[j] ;
            end
        end
    end
endgenerate

// S
genvar k;
generate
    for(k=0; k<Scale; k=k+1)begin
        assign S[Scale*(A_width+B_width)-k*(A_width+B_width)-1-:(A_width+B_width)] = S_array[k] ;
    end
endgenerate

    
endmodule