`timescale 1ns / 1ps

module tb_Mac();

parameter ic_dop        = 3 ; 
parameter oc_dop        = 2 ; 
parameter inp_data_bits = 8 ;
parameter wei_data_bits = 8 ;
parameter out_data_bits = 8 ;

reg                                   I_clk             ;
reg                                   I_rst_n           ;
reg                                   I_acc_reset       ;
reg                                   I_acc_clean       ;
reg [ic_dop*inp_data_bits-1:0]        I_share_activation;
reg [oc_dop*ic_dop*wei_data_bits-1:0] I_multiple_weight ;
wire [oc_dop*out_data_bits-1:0]       O_mac_result      ;

// activation: (pixel_h*pixel_w, input_channel)
//    [[-8  8  0  6  8 -8]
//     [-3 -4  7 -9  5  0]
//     [-2  4 -4  9 -2 -9]
//     [ 5 -1  6 -6 -9  1]]

// weight: (kernel_h*kernel_w, input_channel*output_channel)
//    [[ 1  4 -11 -8 -8 -4 -2  8  7 -7 -5  1]]

// output: ((pixel_h-kernel_h+1)*(pixel_w-kernel_w+1), output_channel)
//    [[-56 -10]        16'hc8_f6
//     [-64  61]        16'hc0_3d
//     [ 38 -54]        16'h26_ca
//     [ 51 112]]       16'h33_70


always #1 I_clk = ~I_clk;
initial begin
I_clk = 1'b0;
I_rst_n = 1'b0;
I_acc_reset = 1'b1;
I_acc_clean = 1'b1;
#15.1;
I_rst_n = 1'b1;
#10;
I_share_activation = 24'hf8_08_00;          // [-8  8  0]
I_multiple_weight  = 48'h01_04_f5_fe_08_07; // [ 1  4 -11 -2  8  7]
#2;
I_acc_reset = 1'b0;
I_acc_clean = 1'b0;
I_share_activation = 24'h06_08_f8;          // [ 6  8 -8]
I_multiple_weight  = 48'hf8_f8_fc_f9_fb_01; // [-8 -8 -4  -7 -5  1]
#2;
I_acc_clean = 1'b0;
I_share_activation = 24'hfd_fc_07;          // [-3 -4  7]
I_multiple_weight  = 48'h01_04_f5_fe_08_07; // [ 1  4 -11 -2  8  7]
#2;
I_acc_clean = 1'b1;
I_share_activation = 24'hf7_05_00;          // [-9  5  0]
I_multiple_weight  = 48'hf8_f8_fc_f9_fb_01; // [-8 -8 -4  -7 -5  1]
#2;
I_acc_clean = 1'b0;
I_share_activation = 24'hfe_04_fc;          // [-2  4 -4]
I_multiple_weight  = 48'h01_04_f5_fe_08_07; // [ 1  4 -11 -2  8  7]
#2;
I_acc_clean = 1'b1;
I_share_activation = 24'h09_fe_f7;          // [ 9 -2 -9]
I_multiple_weight  = 48'hf8_f8_fc_f9_fb_01; // [-8 -8 -4  -7 -5  1]
#2;
I_acc_clean = 1'b0;
I_share_activation = 24'h05_ff_06;          // [ 5 -1  6]
I_multiple_weight  = 48'h01_04_f5_fe_08_07; // [ 1  4 -11 -2  8  7]
#2;
I_acc_clean = 1'b1;
I_share_activation = 24'hfa_f7_01;          // [-6 -9  1]
I_multiple_weight  = 48'hf8_f8_fc_f9_fb_01; // [-8 -8 -4  -7 -5  1]
#2;
I_acc_clean = 1'b0;
#2;
I_acc_clean = 1'b1;
#2;
I_acc_clean = 1'b0;

end

Mac #(
    .ic_dop             (ic_dop            ),
    .oc_dop             (oc_dop            ),
    .inp_data_bits      (inp_data_bits     ),
    .wei_data_bits      (wei_data_bits     ),
    .out_data_bits      (out_data_bits     )
)Mac_inst(
    .I_clk              (I_clk             ),
    .I_rst_n            (I_rst_n           ),
    .I_acc_reset        (I_acc_reset       ),
    .I_acc_clean        (I_acc_clean       ),
    .I_share_activation (I_share_activation),
    .I_multiple_weight  (I_multiple_weight ),
    .O_mac_result       (O_mac_result      )
);
    
endmodule