`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: Qiuhao Zeng
// 
// Create Date: 2025/04/14
// Design Name: 
// Module Name: Mac
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module Mac #(
    parameter ic_dop        = 3 , 
    parameter oc_dop        = 2 , 
    parameter inp_data_bits = 8 ,
    parameter wei_data_bits = 8 ,
    parameter out_data_bits = 8 
)(
    input                                   I_clk             ,
    input                                   I_rst_n           ,
    input                                   I_acc_reset       ,
    input                                   I_acc_clean       ,
    input [ic_dop*inp_data_bits-1:0]        I_share_activation,
    input [oc_dop*ic_dop*wei_data_bits-1:0] I_multiple_weight ,
    output [oc_dop*out_data_bits-1:0]       O_mac_result  
);

wire [ic_dop*(inp_data_bits+wei_data_bits)-1:0] w_mult_result [0:oc_dop-1];
wire [(inp_data_bits+wei_data_bits+ic_dop-1)-1:0] w_adder_result [0:oc_dop-1];
wire [out_data_bits-1:0] w_acc_result [0:oc_dop-1];

// instantiate Multiplier
genvar i;
generate
    for(i=0; i<oc_dop; i=i+1)begin:Multiplier_array
        Multiplier #(
            .A_width    (inp_data_bits     ),
            .B_width    (wei_data_bits     ),
            .Scale      (ic_dop            )
        )Multiplier_inst(
            .I_clk      (I_clk             ),
            .I_rst_n    (I_rst_n           ),
            .A          (I_share_activation),
            .B          (I_multiple_weight[oc_dop*ic_dop*wei_data_bits-i*ic_dop*wei_data_bits-1-:ic_dop*wei_data_bits]),
            .S          (w_mult_result[i]  )
        );
    end
endgenerate

// instantiate Adder
genvar j;
generate
    for(j=0; j<oc_dop; j=j+1)begin:Adder_array
        Adder #(
            .A_width    (inp_data_bits+wei_data_bits),
            .Scale      (ic_dop                     )
        )Adder_inst(
            .A          (w_mult_result[j]           ),
            .S          (w_adder_result[j]          )
        );
    end
endgenerate

// instantiate Accumulator
genvar k;
generate
    for(k=0; k<oc_dop; k=k+1)begin:Accumulator_array
        Accumulator #(
            .A_width     (inp_data_bits+wei_data_bits+ic_dop-1),
            .S_width     (out_data_bits                       )
        )Accumulator_inst(
            .I_clk       (I_clk            ),
            .I_rst_n     (I_rst_n          ),
            .I_acc_reset (I_acc_reset      ),
            .I_acc_clean (I_acc_clean      ),
            .A           (w_adder_result[k]),
            .S           (w_acc_result[k]  )
        );
    end
endgenerate

// O_mac_result
genvar m;
generate
    for(m=0; m<oc_dop; m=m+1)begin
        assign O_mac_result[oc_dop*out_data_bits-m*out_data_bits-1-:out_data_bits] = w_acc_result[m];
    end
endgenerate
    
endmodule